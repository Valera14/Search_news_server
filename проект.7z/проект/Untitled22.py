
# coding: utf-8

# In[ ]:

import re
import numpy as np
from bottle import route, request, run
import lxml.html
import datetime
import requests
import lxml.etree


#Известия
categories = list()
categories.append('15')
categories.append('19')
categories.append('16')
categories.append('28')
categories.append('17')
categories.append('24')
categories.append('25')
categories.append('18')
categories.append('21')
categories.append('87')
categories.append('97')

today = datetime.date.today()
year_current = today.year
month_current = today.month
day_current = today.day

for category in categories:
    f_category = open('izvestia_' + category + '.txt', 'r', encoding='utf-8')
    category_t = f_category.read()
    result = re.findall(r'\w\w\w+', category_t)
    all_words_counter = np.arange(len(result))
    rating_list = np.zeros(len(result))

    final_list_words = list()
    for counter_all in all_words_counter:
        word = result[counter_all]
        list_counter = len(final_list_words)
        list_counter = np.arange(list_counter)
        i = 0
        for counter in list_counter:
            if (final_list_words[counter] == word):
                rating_list[counter] = rating_list[counter] + 1
                i = i+1
        if (i==0):
            final_list_words.append(word)
    if (category == '15'):
        final_words_15 = final_list_words
        rating_list_15 = rating_list
        print(category + 'completed')
    elif (category == '19'):
        final_words_19 = final_list_words
        rating_list_19 = rating_list
        print(category + 'completed')
    elif (category == '16'):
        final_words_16 = final_list_words
        rating_list_16 = rating_list
        print(category + 'completed')
    elif (category == '28'):
        final_words_28 = final_list_words
        rating_list_28 = rating_list
        print(category + 'completed')
    elif (category == '17'):
        final_words_17 = final_list_words
        rating_list_17 = rating_list
        print(category + 'completed')
    elif (category == '24'):
        final_words_24 = final_list_words
        rating_list_24 = rating_list
        print(category + 'completed')
    elif (category == '25'):
        final_words_25 = final_list_words
        rating_list_25 = rating_list
        print(category + 'completed')
    elif (category == '18'):
        final_words_18 = final_list_words
        rating_list_18 = rating_list
        print(category + 'completed')
    elif (category == '21'):
        final_words_21 = final_list_words
        rating_list_21 = rating_list
        print(category + 'completed')
    elif (category == '87'):
        final_words_87 = final_list_words
        rating_list_87 = rating_list
        print(category + 'completed')
    elif (category == '97'):
        final_words_97 = final_list_words
        rating_list_97 = rating_list
        print(category + 'completed')




#newsru.com
categories_newsru = list()
categories_newsru.append('russia')
categories_newsru.append('world')
categories_newsru.append('finance')
categories_newsru.append('religy')
categories_newsru.append('crime')
categories_newsru.append('sport')
categories_newsru.append('cinema')

for category in categories_newsru:
    f_category = open('newsru.com_' + category + '.txt', 'r', encoding='utf-8')
    category_t = f_category.read()
    result = re.findall(r'\w\w\w+', category_t)
    all_words_counter = np.arange(len(result))
    rating_list = np.zeros(len(result))

    final_list_words = list()
    for counter_all in all_words_counter:
        word = result[counter_all]
        list_counter = len(final_list_words)
        list_counter = np.arange(list_counter)
        i = 0
        for counter in list_counter:
            if (final_list_words[counter] == word):
                rating_list[counter] = rating_list[counter] + 1
                i = i+1
        if (i==0):
            final_list_words.append(word)
    if (category == 'russia'):
        final_words_russia = final_list_words
        rating_list_russia = rating_list
        print(category + 'completed')
    elif (category == 'world'):
        final_words_world = final_list_words
        rating_list_world = rating_list
        print(category + 'completed')
    elif (category == 'finance'):
        final_words_finance = final_list_words
        rating_list_finance = rating_list
        print(category + 'completed')
    elif (category == 'religy'):
        final_words_religy = final_list_words
        rating_list_religy = rating_list
        print(category + 'completed')
    elif (category == 'crime'):
        final_words_crime = final_list_words
        rating_list_crime = rating_list
        print(category + 'completed')
    elif (category == 'sport'):
        final_words_sport = final_list_words
        rating_list_sport = rating_list
        print(category + 'completed')
    elif (category == 'cinema'):
        final_words_cinema = final_list_words
        rating_list_cinema = rating_list
        print(category + 'completed')


        

@route('/')
def login():
    return '''
    <head>
    <meta name="viewport" content="width=device-width" />
    <title>Поиск интересующих новостей</title>
    <style type="text/css">
    input{
            box-shadow:8px 13px 13px 7px black;
            color:olive;
            align-content:center;
            font-family:Cambria;
            width:500px;
            height:100px;
            margin-left:120px;
            margin-top:75px;
            text-align:center;
            font-size:30px;
           
        }
    form{
            font-size:30px;
            color:teal;
            margin-left:120px;
            margin-top:75px;
    }
    </style>
    </head>
    <body>
        <form action="/login" method="post">
           <p style="padding-left:200px; padding-top:100px;"> Введите ключевые слова</p> 
           <input name="our_sentence" type="text" />
            <p><input value="Начать поиск" type="submit" /></p>
        </form>
        </body>
    '''
@route('/login', method='POST')
def do_login():
    user_request = (request.forms.get('our_sentence')).encode('latin1').decode('utf8')
    words_news = re.findall(r'\w\w\w+', user_request)

    
    #Известия
    category_point_15, category_point_19, category_point_16 = 0, 0, 0
    category_point_28, category_point_17, category_point_24 = 0, 0, 0
    category_point_25, category_point_18, category_point_21 = 0, 0, 0
    category_point_87, category_point_97 = 0, 0
    
    #newsru.com
    category_point_russia, category_point_world, category_point_finance = 0, 0, 0
    category_point_religy, category_point_crime, category_point_sport = 0, 0, 0
    category_point_cinema = 0
    
    
    
    #Известия
    
    len_15 = len(final_words_15)
    len_15_all = np.arange(len_15)
    print(len_15)
    
    len_19 = len(final_words_19)
    len_19_all = np.arange(len_19)
    print(len_19)
    
    len_16 = len(final_words_16)
    len_16_all = np.arange(len_16)
    print(len_16)
    
    len_28 = len(final_words_28)
    len_28_all = np.arange(len_28)
    print(len_28)
    
    len_17 = len(final_words_17)
    len_17_all = np.arange(len_17)
    
    len_24 = len(final_words_24)
    len_24_all = np.arange(len_24)
    
    len_25 = len(final_words_25)
    len_25_all = np.arange(len_25)
    
    len_18 = len(final_words_18)
    len_18_all = np.arange(len_18)
    
    len_21 = len(final_words_21)
    len_21_all = np.arange(len_21)
    
    len_87 = len(final_words_87)
    len_87_all = np.arange(len_87)
    
    len_97 = len(final_words_97)
    len_97_all = np.arange(len_97)
    
    print(len_17)
    print(len_24)
    print(len_25)
    print(len_18)
    print(len_21)
    print(len_87)
    print(len_97)
   

    #newru.com
    len_russia = len(final_words_russia)
    len_russia_all = np.arange(len_russia)
    print(len_russia)
    
    len_world = len(final_words_world)
    len_world_all = np.arange(len_world)
    print(len_world)
    
    len_finance = len(final_words_finance)
    len_finance_all = np.arange(len_finance)
    print(len_finance)
    
    len_religy = len(final_words_religy)
    len_religy_all = np.arange(len_religy)
    print(len_religy)
    
    len_crime = len(final_words_crime)
    len_crime_all = np.arange(len_crime)
    print(len_crime)
    
    len_sport = len(final_words_sport)
    len_sport_all = np.arange(len_sport)
    print(len_sport)
    
    len_cinema = len(final_words_cinema)
    len_cinema_all = np.arange(len_cinema)
    print(len_cinema)

    
    #Известия
    for word in words_news:
        for counter_15_category in len_15_all:
                if (word == final_words_15[counter_15_category]):
                    category_point_15 = category_point_15 + rating_list_15[counter_15_category] 
        for counter_19_category in len_19_all:
                if (word == final_words_19[counter_19_category]):
                    category_point_19 = category_point_19 + rating_list_19[counter_19_category] 
        for counter_16_category in len_16_all:
                if (word == final_words_16[counter_16_category]):
                    category_point_16 = category_point_16 + rating_list_16[counter_16_category] 
        for counter_28_category in len_28_all:
                if (word == final_words_28[counter_28_category]):
                    category_point_28 = category_point_28 + rating_list_28[counter_28_category] 

        for counter_17_category in len_17_all:
                if (word == final_words_17[counter_17_category]):
                    category_point_17 = category_point_17 + rating_list_17[counter_17_category] 
        for counter_24_category in len_24_all:
                if (word == final_words_24[counter_24_category]):
                    category_point_24 = category_point_24 + rating_list_24[counter_24_category] 
        for counter_25_category in len_25_all:
                if (word == final_words_25[counter_25_category]):
                    category_point_25 = category_point_25 + rating_list_25[counter_25_category] 
        for counter_18_category in len_18_all:
                if (word == final_words_18[counter_18_category]):
                    category_point_18 = category_point_18 + rating_list_18[counter_18_category] 

        for counter_21_category in len_21_all:
                if (word == final_words_21[counter_21_category]):
                    category_point_21 = category_point_21 + rating_list_21[counter_21_category] 
        for counter_87_category in len_87_all:
                if (word == final_words_87[counter_87_category]):
                    category_point_87 = category_point_87 + rating_list_87[counter_87_category] 
        for counter_97_category in len_97_all:
                if (word == final_words_97[counter_97_category]):
                    category_point_97 = category_point_97 + rating_list_97[counter_97_category] 


                    
    #newsru.com
    for word in words_news:
        for counter_russia_category in len_russia_all:
                if (word == final_words_russia[counter_russia_category]):
                    category_point_russia = category_point_russia + rating_list_russia[counter_russia_category] 
        for counter_world_category in len_world_all:
                if (word == final_words_world[counter_world_category]):
                    category_point_world = category_point_world + rating_list_world[counter_world_category] 
        for counter_finance_category in len_finance_all:
                if (word == final_words_finance[counter_finance_category]):
                    category_point_finance = category_point_finance + rating_list_finance[counter_finance_category] 
        for counter_religy_category in len_religy_all:
                if (word == final_words_religy[counter_religy_category]):
                    category_point_religy = category_point_religy + rating_list_religy[counter_religy_category] 

        for counter_crime_category in len_crime_all:
                if (word == final_words_crime[counter_crime_category]):
                    category_point_crime = category_point_crime + rating_list_crime[counter_crime_category] 
        for counter_sport_category in len_sport_all:
                if (word == final_words_sport[counter_sport_category]):
                    category_point_sport = category_point_sport + rating_list_sport[counter_sport_category] 
        for counter_cinema_category in len_cinema_all:
                if (word == final_words_cinema[counter_cinema_category]):
                    category_point_cinema = category_point_cinema + rating_list_cinema[counter_cinema_category] 


    #Известия
    rating_list_final = list()
    rating_list_final.append(category_point_15/len_15)
    rating_list_final.append(category_point_19/len_19)
    rating_list_final.append(category_point_16/len_16)
    rating_list_final.append(category_point_28/len_28)
    rating_list_final.append(category_point_17/len_17)
    rating_list_final.append(category_point_24/len_24)
    rating_list_final.append(category_point_25/len_25)
    rating_list_final.append(category_point_18/len_18)
    rating_list_final.append(category_point_21/len_21)
    rating_list_final.append(category_point_87/len_87)
    rating_list_final.append(category_point_97/len_97)
    
    selected_category = np.argmax(rating_list_final)
    
    category = str(categories[selected_category])
    selected_html = 'http://izvestia.ru/rubric/' + category
    response = requests.get(selected_html)
    tree = lxml.html.fromstring(response.text)
    f13 = tree.xpath('//h2/a[@href]/text()')
    f5 = tree.xpath('//h2/a[@href]/@href')
    
    len_pages = len(f5)
    len_pages5 = np.arange(len_pages)
    
    for page in len_pages5:
        f5[page] = 'http://izvestia.ru' + str(f5[page])
    
    
    
    #newsru
    rating_list_final_newsru = list()
    rating_list_final_newsru.append(category_point_russia/len_russia)
    rating_list_final_newsru.append(category_point_world/len_world)
    rating_list_final_newsru.append(category_point_finance/len_finance)
    rating_list_final_newsru.append(category_point_religy/len_religy)
    rating_list_final_newsru.append(category_point_crime/len_crime)
    rating_list_final_newsru.append(category_point_sport/len_sport)
    rating_list_final_newsru.append(category_point_cinema/len_cinema)
    
    selected_category = np.argmax(rating_list_final_newsru)
    
    category = str(categories_newsru[selected_category])
    selected_html = 'http://www.newsru.com/' + category
    response = requests.get(selected_html)
    tree = lxml.html.fromstring(response.text)
    f13_newsru = tree.xpath('//div/a[@class="index-news-title"]/text()')
    f5_newsru = tree.xpath('//div/a[@class="index-news-title"]/@href')
    
    len_pages = len(f5_newsru)
    len_pages5 = np.arange(len_pages)
    
    for page in len_pages5:
        f5_newsru[page] = 'http://www.newsru.com' + str(f5_newsru[page])
    
    
    
    
    user_request = (request.forms.get('our_sentence')).encode('latin1').decode('utf8')
    return '''
    <head>
    <meta name="viewport" content="width=device-width" />
    <title>Поиск интересующих новостей</title>
    <style type="text/css">
        div{
            box-shadow:8px 13px 13px 7px black;
            color:olive;
            align-content:center;
            font-family:Cambria;
            width:500px;
            height:1000px;
            margin-left:120px;
            margin-top:75px;
            text-align:center;
            font-size:14px;
           
        }
    </style>
    </head>
    <body>
        <div>
        <h3> По запросу "
            ''' + user_request + '''
        " было найдено:
        </h3>
        <h5>
        ''' + str(f13[0]) + '''
        </h5>
        <h5><a href="''' + str(f5[0]) + '''">Узнать подробнее</a>
        </h5>
        <h5>
        ''' + str(f13[1]) + '''
        </h5>
        <h5><a href="''' + str(f5[1]) + '''">Узнать подробнее</a>
        </h5>
        <h5>
        ''' + str(f13[2]) + '''
        </h5>
        <h5><a href="''' + str(f5[2]) + '''">Узнать подробнее</a>
        </h5>
        <h5>
        ''' + str(f13[3]) + '''
        </h5>
        <h5><a href="''' + str(f5[3]) + '''">Узнать подробнее</a>
        </h5>
        
        <h5>
        ''' + str(f13_newsru[0]) + '''
        </h5>
        <h5><a href="''' + str(f5_newsru[0]) + '''">Узнать подробнее</a>
        </h5>
        
        <h5>
        ''' + str(f13_newsru[1]) + '''
        </h5>
        <h5><a href="''' + str(f5_newsru[1]) + '''">Узнать подробнее</a>
        </h5>
        <h5>
        ''' + str(f13_newsru[2]) + '''
        </h5>
        <h5><a href="''' + str(f5_newsru[2]) + '''">Узнать подробнее</a>
        </h5>
        <h5>
        ''' + str(f13_newsru[3]) + '''
        </h5>
        <h5><a href="''' + str(f5_newsru[3]) + '''">Узнать подробнее</a>
        </h5>
        </div>
    </body>
    '''


# In[ ]:

run(host='localhost', port=5000)

